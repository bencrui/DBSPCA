﻿
namespace DBSPCA
{
    partial class FoodForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea4 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend4 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series4 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Title title4 = new System.Windows.Forms.DataVisualization.Charting.Title();
            this.lblDay7 = new System.Windows.Forms.Label();
            this.lblDay2 = new System.Windows.Forms.Label();
            this.lblDay3 = new System.Windows.Forms.Label();
            this.lblDay4 = new System.Windows.Forms.Label();
            this.lblDay5 = new System.Windows.Forms.Label();
            this.lblDay6 = new System.Windows.Forms.Label();
            this.lblDay1 = new System.Windows.Forms.Label();
            this.MainTitleTxb = new System.Windows.Forms.Label();
            this.Day7Nud = new System.Windows.Forms.NumericUpDown();
            this.Day6Nud = new System.Windows.Forms.NumericUpDown();
            this.Day5Nud = new System.Windows.Forms.NumericUpDown();
            this.Day4Nud = new System.Windows.Forms.NumericUpDown();
            this.Day3Nud = new System.Windows.Forms.NumericUpDown();
            this.Day2Nud = new System.Windows.Forms.NumericUpDown();
            this.Day1Nud = new System.Windows.Forms.NumericUpDown();
            this.miniChart = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.btnAdd = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.Day7Nud)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Day6Nud)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Day5Nud)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Day4Nud)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Day3Nud)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Day2Nud)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Day1Nud)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.miniChart)).BeginInit();
            this.SuspendLayout();
            // 
            // lblDay7
            // 
            this.lblDay7.AutoSize = true;
            this.lblDay7.Font = new System.Drawing.Font("Palatino Linotype", 15.75F, System.Drawing.FontStyle.Bold);
            this.lblDay7.Location = new System.Drawing.Point(64, 334);
            this.lblDay7.Name = "lblDay7";
            this.lblDay7.Size = new System.Drawing.Size(73, 28);
            this.lblDay7.TabIndex = 16;
            this.lblDay7.Text = "Day 7:";
            // 
            // lblDay2
            // 
            this.lblDay2.AutoSize = true;
            this.lblDay2.Font = new System.Drawing.Font("Palatino Linotype", 15.75F, System.Drawing.FontStyle.Bold);
            this.lblDay2.Location = new System.Drawing.Point(64, 145);
            this.lblDay2.Name = "lblDay2";
            this.lblDay2.Size = new System.Drawing.Size(73, 28);
            this.lblDay2.TabIndex = 15;
            this.lblDay2.Text = "Day 2:";
            // 
            // lblDay3
            // 
            this.lblDay3.AutoSize = true;
            this.lblDay3.Font = new System.Drawing.Font("Palatino Linotype", 15.75F, System.Drawing.FontStyle.Bold);
            this.lblDay3.Location = new System.Drawing.Point(64, 183);
            this.lblDay3.Name = "lblDay3";
            this.lblDay3.Size = new System.Drawing.Size(73, 28);
            this.lblDay3.TabIndex = 14;
            this.lblDay3.Text = "Day 3:";
            // 
            // lblDay4
            // 
            this.lblDay4.AutoSize = true;
            this.lblDay4.Font = new System.Drawing.Font("Palatino Linotype", 15.75F, System.Drawing.FontStyle.Bold);
            this.lblDay4.Location = new System.Drawing.Point(64, 221);
            this.lblDay4.Name = "lblDay4";
            this.lblDay4.Size = new System.Drawing.Size(73, 28);
            this.lblDay4.TabIndex = 13;
            this.lblDay4.Text = "Day 4:";
            // 
            // lblDay5
            // 
            this.lblDay5.AutoSize = true;
            this.lblDay5.Font = new System.Drawing.Font("Palatino Linotype", 15.75F, System.Drawing.FontStyle.Bold);
            this.lblDay5.Location = new System.Drawing.Point(64, 258);
            this.lblDay5.Name = "lblDay5";
            this.lblDay5.Size = new System.Drawing.Size(73, 28);
            this.lblDay5.TabIndex = 12;
            this.lblDay5.Text = "Day 5:";
            // 
            // lblDay6
            // 
            this.lblDay6.AutoSize = true;
            this.lblDay6.Font = new System.Drawing.Font("Palatino Linotype", 15.75F, System.Drawing.FontStyle.Bold);
            this.lblDay6.Location = new System.Drawing.Point(64, 296);
            this.lblDay6.Name = "lblDay6";
            this.lblDay6.Size = new System.Drawing.Size(73, 28);
            this.lblDay6.TabIndex = 11;
            this.lblDay6.Text = "Day 6:";
            // 
            // lblDay1
            // 
            this.lblDay1.AutoSize = true;
            this.lblDay1.Font = new System.Drawing.Font("Palatino Linotype", 15.75F, System.Drawing.FontStyle.Bold);
            this.lblDay1.Location = new System.Drawing.Point(64, 109);
            this.lblDay1.Name = "lblDay1";
            this.lblDay1.Size = new System.Drawing.Size(73, 28);
            this.lblDay1.TabIndex = 10;
            this.lblDay1.Text = "Day 1:";
            // 
            // MainTitleTxb
            // 
            this.MainTitleTxb.AutoSize = true;
            this.MainTitleTxb.Font = new System.Drawing.Font("Palatino Linotype", 24F);
            this.MainTitleTxb.Location = new System.Drawing.Point(196, 27);
            this.MainTitleTxb.Name = "MainTitleTxb";
            this.MainTitleTxb.Size = new System.Drawing.Size(380, 44);
            this.MainTitleTxb.TabIndex = 17;
            this.MainTitleTxb.Text = "NAME\'s Weekly Food (g)";
            // 
            // Day7Nud
            // 
            this.Day7Nud.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.Day7Nud.Location = new System.Drawing.Point(165, 335);
            this.Day7Nud.Maximum = new decimal(new int[] {
            15000,
            0,
            0,
            0});
            this.Day7Nud.Name = "Day7Nud";
            this.Day7Nud.Size = new System.Drawing.Size(171, 29);
            this.Day7Nud.TabIndex = 25;
            // 
            // Day6Nud
            // 
            this.Day6Nud.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.Day6Nud.Location = new System.Drawing.Point(165, 297);
            this.Day6Nud.Maximum = new decimal(new int[] {
            15000,
            0,
            0,
            0});
            this.Day6Nud.Name = "Day6Nud";
            this.Day6Nud.Size = new System.Drawing.Size(171, 29);
            this.Day6Nud.TabIndex = 24;
            // 
            // Day5Nud
            // 
            this.Day5Nud.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.Day5Nud.Location = new System.Drawing.Point(165, 259);
            this.Day5Nud.Maximum = new decimal(new int[] {
            15000,
            0,
            0,
            0});
            this.Day5Nud.Name = "Day5Nud";
            this.Day5Nud.Size = new System.Drawing.Size(171, 29);
            this.Day5Nud.TabIndex = 23;
            // 
            // Day4Nud
            // 
            this.Day4Nud.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.Day4Nud.Location = new System.Drawing.Point(165, 222);
            this.Day4Nud.Maximum = new decimal(new int[] {
            15000,
            0,
            0,
            0});
            this.Day4Nud.Name = "Day4Nud";
            this.Day4Nud.Size = new System.Drawing.Size(171, 29);
            this.Day4Nud.TabIndex = 22;
            // 
            // Day3Nud
            // 
            this.Day3Nud.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.Day3Nud.Location = new System.Drawing.Point(165, 184);
            this.Day3Nud.Maximum = new decimal(new int[] {
            15000,
            0,
            0,
            0});
            this.Day3Nud.Name = "Day3Nud";
            this.Day3Nud.Size = new System.Drawing.Size(171, 29);
            this.Day3Nud.TabIndex = 21;
            // 
            // Day2Nud
            // 
            this.Day2Nud.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.Day2Nud.Location = new System.Drawing.Point(165, 146);
            this.Day2Nud.Maximum = new decimal(new int[] {
            15000,
            0,
            0,
            0});
            this.Day2Nud.Name = "Day2Nud";
            this.Day2Nud.Size = new System.Drawing.Size(171, 29);
            this.Day2Nud.TabIndex = 20;
            // 
            // Day1Nud
            // 
            this.Day1Nud.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.Day1Nud.Location = new System.Drawing.Point(165, 110);
            this.Day1Nud.Maximum = new decimal(new int[] {
            15000,
            0,
            0,
            0});
            this.Day1Nud.Name = "Day1Nud";
            this.Day1Nud.Size = new System.Drawing.Size(171, 29);
            this.Day1Nud.TabIndex = 19;
            // 
            // miniChart
            // 
            chartArea4.Name = "ChartArea1";
            this.miniChart.ChartAreas.Add(chartArea4);
            legend4.Name = "Legend1";
            this.miniChart.Legends.Add(legend4);
            this.miniChart.Location = new System.Drawing.Point(432, 109);
            this.miniChart.Name = "miniChart";
            series4.ChartArea = "ChartArea1";
            series4.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series4.Legend = "Legend1";
            series4.Name = "Food";
            this.miniChart.Series.Add(series4);
            this.miniChart.Size = new System.Drawing.Size(323, 253);
            this.miniChart.TabIndex = 27;
            title4.Name = "Food";
            this.miniChart.Titles.Add(title4);
            // 
            // btnAdd
            // 
            this.btnAdd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(227)))), ((int)(((byte)(115)))), ((int)(((byte)(131)))));
            this.btnAdd.Font = new System.Drawing.Font("Palatino Linotype", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnAdd.Location = new System.Drawing.Point(238, 370);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(98, 23);
            this.btnAdd.TabIndex = 28;
            this.btnAdd.Text = "Add Food";
            this.btnAdd.UseVisualStyleBackColor = false;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(65)))), ((int)(((byte)(65)))));
            this.button1.Font = new System.Drawing.Font("Palatino Linotype", 8.25F, System.Drawing.FontStyle.Bold);
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(657, 370);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(98, 23);
            this.button1.TabIndex = 30;
            this.button1.Text = "Exit";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // FoodForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(223)))), ((int)(((byte)(203)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.miniChart);
            this.Controls.Add(this.Day7Nud);
            this.Controls.Add(this.Day6Nud);
            this.Controls.Add(this.Day5Nud);
            this.Controls.Add(this.Day4Nud);
            this.Controls.Add(this.Day3Nud);
            this.Controls.Add(this.Day2Nud);
            this.Controls.Add(this.Day1Nud);
            this.Controls.Add(this.MainTitleTxb);
            this.Controls.Add(this.lblDay7);
            this.Controls.Add(this.lblDay2);
            this.Controls.Add(this.lblDay3);
            this.Controls.Add(this.lblDay4);
            this.Controls.Add(this.lblDay5);
            this.Controls.Add(this.lblDay6);
            this.Controls.Add(this.lblDay1);
            this.Name = "FoodForm";
            this.Text = "FoodForm";
            this.Load += new System.EventHandler(this.FoodForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Day7Nud)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Day6Nud)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Day5Nud)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Day4Nud)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Day3Nud)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Day2Nud)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Day1Nud)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.miniChart)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblDay7;
        private System.Windows.Forms.Label lblDay2;
        private System.Windows.Forms.Label lblDay3;
        private System.Windows.Forms.Label lblDay4;
        private System.Windows.Forms.Label lblDay5;
        private System.Windows.Forms.Label lblDay6;
        private System.Windows.Forms.Label lblDay1;
        private System.Windows.Forms.Label MainTitleTxb;
        private System.Windows.Forms.NumericUpDown Day7Nud;
        private System.Windows.Forms.NumericUpDown Day6Nud;
        private System.Windows.Forms.NumericUpDown Day5Nud;
        private System.Windows.Forms.NumericUpDown Day4Nud;
        private System.Windows.Forms.NumericUpDown Day3Nud;
        private System.Windows.Forms.NumericUpDown Day2Nud;
        private System.Windows.Forms.NumericUpDown Day1Nud;
        private System.Windows.Forms.DataVisualization.Charting.Chart miniChart;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button button1;
    }
}