﻿SELECT * FROM tblAnimals
WHERE animalId = 2;